/*
 *  ChatServiceFramework.h
 *  ChatService
 *
 
 *  Copyright 2012 QuickBlox team. All rights reserved.
 *
 */

#import <Quickblox/QBChatClasses.h>