/*
 *  BaseServiceFramework.h
 *  BaseService
 *
 *
 */

#import <Quickblox/QBCoreBusiness.h>
